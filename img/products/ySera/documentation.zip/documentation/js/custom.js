$(function() {
"use strict";
    SyntaxHighlighter.all();
    $('#nav').singlePageNav();
    

});