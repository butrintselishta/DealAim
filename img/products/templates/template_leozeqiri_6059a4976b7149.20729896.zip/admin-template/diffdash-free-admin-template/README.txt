-----------------------
# README
-----------------------

DiffDash is a free simple and unique admin dashboard template that provide most important elements for your project. It provides essential UI elements and pages such as profile, login, register, lockscreen and error page.


Template Info:
-----------------------
Name: 		DiffDash - Free Admin Dashboard
Version: 	1.0
Author: 	The Develovers
Website: 	https://www.themeineed.com/


License:
-----------------------
This template follows our Free License terms https://www.themeineed.com/licenses/

- You may use free item for personal and/or commercial use, attribution is required. Please put a link on your work to https://www.themeineed.com/
- Item (modified or unmodified) can not be resold.
- You may charge your client for your services to create an end-product incorporating this item as long as the end-product is not for sale.
- Item can not be redistributed as is. You can not offer the item as is for free redistribution such as placed in website that offer free stock items/templates.
- You may convert a template to CMS theme for free distribution only, attribution is required.
- We don’t provide any support for free items/templates.

